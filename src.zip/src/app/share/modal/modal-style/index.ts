export * from './modal-style.module';
export * from './modal-style.service';