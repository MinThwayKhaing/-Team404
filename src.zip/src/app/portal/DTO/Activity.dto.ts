export class Activity{

    activityId !: number
    activityName !: string
    taskId !: string
    status !: string
    cardId !:string
    
}