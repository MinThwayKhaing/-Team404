export class Board{
    
    boardId !: number
    boardName !: string
    workspaceId !: number
}