import { User } from "./user";

export class UserTaskList
{
    userList ?: [User] ;
	id !: String
	name!: String
	startDate !: String
	endDate !: String
 	cardId !: String
	startTime !: String
	endTime !: String
 	description !: String
	
}