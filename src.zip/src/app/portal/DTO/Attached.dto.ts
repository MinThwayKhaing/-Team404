import { Activity } from "./Activity.dto"

export class Attached{

    id !: number
    name !: string
    activityId !: number
    files ?: any 
    


}