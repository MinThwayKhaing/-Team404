import { User } from "./user";

export class Member
{
    status ?: string;
    listUser ?: [User]
    id !: number
    currentUserName ?: string;
	userId ?:number
	email ?: string


}
