export class Attach{

    id !: number
    name !: string
    deleteStatus !: boolean
    resource !: string
    activity : any


}