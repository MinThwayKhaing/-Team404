import { Tasks } from "./task.dto";

export class TaskList{

    taskList !: Tasks[]
}