export class Comments{

    id !: number;
    name !: string
    userName !: string
    date !: string
    time !: string
    taskId !: string
    userId !: number

}