export const Url = {
    Login_URL : '/login',
    Register_User : '/register',
    Forget_Pwd : '/forgetpwd',
    Change_Pwd : '/chnpwd',
    Show_Profile : '/showPf',
    Update_User : '/update',

    
    Create_WorkSpace : '/createWorkspace',
    Show_AllWorkSpace : '/showAllWorkSpace',

    Show_Member : '/showWorkspacemember',
    Add_Member : '/addMember',

    Member : '/memberWorkspace',
    Card : '/Card',
    Create_Card : '/ShowAllCard'
}