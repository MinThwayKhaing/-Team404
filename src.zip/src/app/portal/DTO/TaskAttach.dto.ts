import { Attached } from "./Attached.dto"

export class TaskAttach {
    activityId !: number
    attach : Attached [] =[]
}