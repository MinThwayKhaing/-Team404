export class User  {
   
    id ?:number;
    name ?:string;
    email ?:string;
    password ?:string;
    confirm ?:string;
    pic ?:string;
    role ?:string;
    enable ?:boolean;
    picname ?:string;
    
}