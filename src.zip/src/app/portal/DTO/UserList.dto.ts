export class UserListDTO{

    //id ?: number
    taskId ?: string
    userId ?: [] = []

}