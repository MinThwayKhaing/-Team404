import { Board } from "./board.dto";

export class WorkspaceBoard
{
    boardId !: number
    boardName !: string
}