export class Tasks 
{
    id !: string
    name !: string
    description !: string
    startDate !: string
    endDate !: string
    startTime !: string
    endTime !: string
    cardId !: string

}