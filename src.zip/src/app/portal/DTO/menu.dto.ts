export interface Menu {
    title?: string,
    svg?: string,
    route?: string,
}