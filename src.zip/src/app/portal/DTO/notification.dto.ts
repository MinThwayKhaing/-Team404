export class NotificationDTO{

    id !: number
    name !: String
    type !: String 
    userId !: number
    
}