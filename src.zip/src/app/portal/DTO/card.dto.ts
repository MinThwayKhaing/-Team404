export class Cards
{
    cardId !: string
    cardName !: String
    type !: String
}