export class Boards
{
    boardId !: number
    boardName !: string
    workspaceId !: number
}