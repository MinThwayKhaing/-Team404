import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-changepasswordpopup',
  templateUrl: './changepasswordpopup.component.html',
  styleUrls: ['./changepasswordpopup.component.scss']
})
export class ChangepasswordpopupComponent implements OnInit {
      a: any;
  constructor(public dialogRef: MatDialogRef<ChangepasswordpopupComponent>) { }

  ngOnInit(): void {
  }

  
  onNoClick(): void {
    this.dialogRef.close();
  }
}
