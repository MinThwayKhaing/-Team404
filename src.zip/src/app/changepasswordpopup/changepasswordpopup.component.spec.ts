import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangepasswordpopupComponent } from './changepasswordpopup.component';

describe('ChangepasswordpopupComponent', () => {
  let component: ChangepasswordpopupComponent;
  let fixture: ComponentFixture<ChangepasswordpopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangepasswordpopupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChangepasswordpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
