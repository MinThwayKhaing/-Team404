import { ContentEditDirective } from './content-edit.directive';

describe('ContentEditDirective', () => {
  it('should create an instance', () => {
    const directive = new ContentEditDirective(null,null);
    expect(directive).toBeTruthy();
  });
});
